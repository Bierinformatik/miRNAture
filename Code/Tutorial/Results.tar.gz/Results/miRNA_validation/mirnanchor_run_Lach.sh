#!/bin/bash

####
# miRNAture
# Cristian A. Velandia-Huerto, Joerg Fallmann, Peter F. Stadler
# Feb 1 2021
# v.1.0
####
# Session data:
# Hostname: unknownd89c6795a673
# Date:Thu Feb  4 10:46:04 CET 2021
# User:bioinf
# Program: miRNAnchor
####
#Validation miRNAs
/home/bioinf/Desktop/miRNAture/Code/src/miRNAnchor.pl -c /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/miRNA_prediction/Final_Candidates/Fasta -m /home/bioinf/anaconda3/envs/miRNAture2/bin/MIRfix.py -o /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results -e /home/bioinf/Desktop/miRNAture/Code/Data/Validation_mature_data -og /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Data/latimeria_chalumnae_genome.fa -g /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/TemporalFiles/Latimeria_chalumnae/latimeria_chalumnae_genome.fa.new.fa -db /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/miRNA_prediction/Final_Candidates/all_RFAM_Lach_Final.ncRNAs_homology.txt.db -p 0 -tag Lach

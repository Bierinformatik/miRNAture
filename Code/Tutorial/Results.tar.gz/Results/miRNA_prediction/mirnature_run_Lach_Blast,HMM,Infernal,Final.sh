#!/bin/bash

####
# miRNAture
# Cristian A. Velandia-Huerto
# Mon Mar 16 19:02:25 CET 2020
# v.1.0
####
# Session data:
# Hostname: k70.bioinf.uni-leipzig.de
# Date:Mon 01 Feb 2021 05:00:22 PM CET
# User:cristian
# Program: miRNAture
####
#BLAST searches
/homes/biertank/cristian/Projects/miRNAture_v1/Code/src/miRNAture.pl  -l /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/list_miRNAs_to_search.txt -m BLAST -str 9,10,ALL -blstq /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Data/QueriesToTest -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results/miRNA_prediction -data /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data -cmp /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/RFAM_14-4/CMs /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/Other_CM -hmmp /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/RFAM_14-4/HMMs/ -rep default,150,100
#HMM searches
/homes/biertank/cristian/Projects/miRNAture_v1/Code/src/miRNAture.pl -l /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/list_miRNAs_to_search.txt -m HMM -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results/miRNA_prediction -data /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data -cmp /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/RFAM_14-4/CMs /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/Other_CM -hmmp /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/RFAM_14-4/HMMs/ -rep default,150,100
#Infernal searches
/homes/biertank/cristian/Projects/miRNAture_v1/Code/src/miRNAture.pl -l /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/list_miRNAs_to_search.txt -m INFERNAL -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results/miRNA_prediction -data /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data -cmp /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/RFAM_14-4/CMs -hmmp /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/RFAM_14-4/HMMs/ -rep default,150,100
#Final searches
/homes/biertank/cristian/Projects/miRNAture_v1/Code/src/miRNAture.pl -l /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/list_miRNAs_to_search.txt -m Final -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results/miRNA_prediction -data /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data -rep default,150,100

#!/bin/bash

####
# miRNAture
# Cristian A. Velandia-Huerto, Joerg Fallmann, Peter F. Stadler
# Feb 1 2021
# v.1.0
####
# Session data:
# Hostname: unknownd89c6795a673
# Date:Thu Feb  4 10:46:04 CET 2021
# User:bioinf
# Program: miRNAture
####
#BLAST searches
/home/bioinf/Desktop/miRNAture/Code/src/miRNAture.pl  -l /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/list_miRNAs_to_search.txt -m BLAST -str 5,6,ALL -blstq /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Data/QueriesToTest -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/miRNA_prediction -data /home/bioinf/Desktop/miRNAture/Code/Data -cmp /home/bioinf/Desktop/miRNAture/Code/Data/RFAM_14-4/CMs /home/bioinf/Desktop/miRNAture/Code/Data/Other_CM -hmmp /home/bioinf/Desktop/miRNAture/Code/Data/RFAM_14-4/HMMs /home/bioinf/Desktop/miRNAture/Code/Data/Other_HMM -rep default,150,100
#HMM searches
/home/bioinf/Desktop/miRNAture/Code/src/miRNAture.pl -l /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/list_miRNAs_to_search.txt -m HMM -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/miRNA_prediction -data /home/bioinf/Desktop/miRNAture/Code/Data -cmp /home/bioinf/Desktop/miRNAture/Code/Data/RFAM_14-4/CMs /home/bioinf/Desktop/miRNAture/Code/Data/Other_CM -hmmp /home/bioinf/Desktop/miRNAture/Code/Data/RFAM_14-4/HMMs /home/bioinf/Desktop/miRNAture/Code/Data/Other_HMM -rep default,150,100
#Infernal searches
/home/bioinf/Desktop/miRNAture/Code/src/miRNAture.pl -l /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/list_miRNAs_to_search.txt -m INFERNAL -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/miRNA_prediction -data /home/bioinf/Desktop/miRNAture/Code/Data -cmp /home/bioinf/Desktop/miRNAture/Code/Data/RFAM_14-4/CMs -hmmp /home/bioinf/Desktop/miRNAture/Code/Data/RFAM_14-4/HMMs /home/bioinf/Desktop/miRNAture/Code/Data/Other_HMM -rep default,150,100
#Other searches
/home/bioinf/Desktop/miRNAture/Code/src/miRNAture.pl -l /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/list_miRNAs_to_search.txt -m OTHER_CM -pe 0 -nmodels /home/bioinf/Desktop/miRNAture/Code/Data/Other_CM -spe Lach -n_spe Latimeria_chalumnae -w /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/miRNA_prediction -data /home/bioinf/Desktop/miRNAture/Code/Data -cmp /home/bioinf/Desktop/miRNAture/Code/Data/Other_CM -hmmp /home/bioinf/Desktop/miRNAture/Code/Data/RFAM_14-4/HMMs /home/bioinf/Desktop/miRNAture/Code/Data/Other_HMM -rep default,150,100
#Final searches
/home/bioinf/Desktop/miRNAture/Code/src/miRNAture.pl -l /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/list_miRNAs_to_search.txt -m Final -pe 0 -spe Lach -n_spe Latimeria_chalumnae -w /home/bioinf/Desktop/miRNAture/Code/Tutorial/Code/../Results/miRNA_prediction -data /home/bioinf/Desktop/miRNAture/Code/Data -rep default,150,100

#!/bin/bash

####
# miRNAture
# Cristian A. Velandia-Huerto
# Mon Mar 16 19:02:25 CET 2020
# v.1.0
####
# Session data:
# Hostname: k70.bioinf.uni-leipzig.de
# Date:Mon 01 Feb 2021 05:21:38 PM CET
# User:cristian
# Program: miRNAnchor
####
#Validation miRNAs
/homes/biertank/cristian/Projects/miRNAture_v1/Code/src/miRNAnchor.pl -c /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results/miRNA_prediction/Final_Candidates/Fasta -m /homes/biertank/cristian/Projects/MIRfix/scripts/MIRfix.py -o /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results -e /homes/biertank/cristian/Projects/miRNAture_v1/Code/Data/Validation_mature_data -og /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Data/latimeria_chalumnae_genome.fa -g /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results/TemporalFiles/Latimeria_chalumnae/latimeria_chalumnae_genome.fa.new.fa -db /homes/biertank/cristian/Projects/miRNAture_v1/Code/Tutorial/Code/../Results/miRNA_prediction/Final_Candidates/all_RFAM_Lach_Final.ncRNAs_homology.txt.db -p 0 -tag Lach
